from Game_Mechanics.Menu import *
from Players.HumanPlayer import HumanPlayer
from Players.RandomPlayer import RandomPlayer
from Players.ArbelDaniella import ArbelDaniella
from Players.First_utility import First_utility

run_game(HumanPlayer(), First_utility())
