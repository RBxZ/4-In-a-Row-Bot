from Game_Mechanics import Adverseries
from Basic_Things import Basic_Game_Functions

LEVELS = 6
class First_utility:
    def __init__(self):
        pass

    def get_move(self, board, player):
        return minimax(True, board, 0, player)[1]


def minimax(maximum, board, count, player):
        if Basic_Game_Functions.Winner_check(board, player) == player:
            return 100 - count, -1
        elif Basic_Game_Functions.Winner_check(board, 3-player) == 3-player:
            return -100 + count, -1
        elif Basic_Game_Functions.tie_check(board):
            return 0, -1

        scores = []
        for move in range(7):
            check, board = Basic_Game_Functions.apply_move(board, move, player)
            if check:
                if count == LEVELS - 1:
                    scores.append((utility(board, player), move))
                else:
                    scores.append((-minimax(maximum, board, count + 1, 3 - player)[0], move))
                board = Basic_Game_Functions.regret_move(board, move, player)


        max_score = scores[0]
        for score in scores:
            if score[0] > max_score[0]:
                max_score = score
        return max_score

def utility(board, player):
    score = 0
    my_open_trios, op_open_trios = count_open_trios(board, player)
    score = score + 0.1 * count_close_to_middle(board, player) + 0.3 * (my_open_trios - op_open_trios) + 10 * count_forks(board, player, my_open_trios, op_open_trios) + 100 * count_best(board, player)
    return score

def close_to_middle(board, player):

def count_couples_open_on_one_side(board, player):

def count_couples_open_on_both_sides(board, player):

def count_trios_open_on_one_side(board, player):

def count_trios_open_on_both_sides(board, player):
    