from Game_Mechanics import Adverseries
from Basic_Things import Basic_Game_Functions

LEVELS = 6
class ArbelDaniella:
    def __init__(self):
        pass

    def get_move(self, board, player):
        return minimax(True, board, 0, player)[1]


def minimax(maximum, board, count, player):
        if Basic_Game_Functions.Winner_check(board, player) == player:
            return 100 - count, -1
        elif Basic_Game_Functions.Winner_check(board, 3-player) == 3-player:
            return -100 + count, -1
        elif Basic_Game_Functions.tie_check(board):
            return 0, -1

        scores = []
        for move in range(7):
            check, board = Basic_Game_Functions.apply_move(board, move, player)
            if check:
                if count == LEVELS - 1:
                    scores.append((utility(board, player), move))
                else:
                    scores.append((-minimax(maximum, board, count + 1, 3 - player)[0], move))
                board = Basic_Game_Functions.regret_move(board, move, player)


        max_score = scores[0]
        for score in scores:
            if score[0] > max_score[0]:
                max_score = score
        return max_score

def utility(board, player):
    score = 0
    my_open_trios, op_open_trios = count_open_trios(board, player)
    score = score + 0.1 * count_close_to_middle(board, player) + 0.3 * (my_open_trios - op_open_trios) + 0.4 * count_forks(board, player, my_open_trios, op_open_trios) + 0.25 * count_open_couples_on_both_sides(board, player)
    return score

def count_close_to_middle(board, player):
    c = 0
    for col in range(2, 5):
        for row in range(6):
            if board[row][col] == player:
                c += 1
            elif board[row][col] == 3 - player:
                c -= 1
    return c

def count_trios(board, player):
    c = 0
    #vertical
    for col in range(7):
        row = 5
        for i in range(4):
            if board[row-i][col] == board[row-i-1][col] == board[row-i-2][col] == player:
                c += 1
            elif board[row-i][col] == board[row-i-1][col] == board[row-i-2][col] == 3 - player:
                c -= 1
    #horizontal
    for row in range(6):
        col = 0
        for i in range(5):
            if board[row][col+i] == board[row][col+i+1] == board[row][col+i+2] == player:
                c += 1
            elif board[row][col+i] == board[row][col+i+1] == board[row][col+i+2] == 3 - player:
                c -= 1
    #diagonal
    for col in range(4):
        for row in range(5, 1, -1):
            if board[row][col] == board[row-1][col+1] == board[row-2][col+2] == player:
                c += 1
            elif board[row][col] == board[row-1][col+1] == board[row-2][col+2] == 3 - player:
                c -= 1
        for row in range(4):
            if board[row][col] == board[row+1][col+1] == board[row+2][col+2] == player:
                c += 1
            elif board[row][col] == board[row+1][col+1] == board[row+2][col+2] == 3 - player:
                c -= 1
    return c

def count_open_trios(board, player):
    c1 = 0
    c2 = 0
    # vertical
    for col in range(7):
        row = 5
        for i in range(3):
            if board[row - i][col] == board[row - i - 1][col] == board[row - i - 2][col] == player and board[row - i - 3][col] == 0:
                c1 += 1
            elif board[row - i][col] == board[row - i - 1][col] == board[row - i - 2][col] == 3 - player and board[row - i - 3][col] == 0:
                c2 += 1
    # horizontal
    for row in range(6):
        col = 0
        for i in range(4):
            if board[row][col + i] == board[row][col + i + 1] == board[row][col + i + 2] == player and board[row][col + i + 3] == 0:
                c1 += 1
            elif board[row][col + i] == board[row][col + i + 1] == board[row][col + i + 2] == 3 - player and board[row][col + i + 3] == 0:
                c2 += 1
        for i in range(1,5):
            if board[row][col + i] == board[row][col + i + 1] == board[row][col + i + 2] == player and board[row][col + i - 1] == 0:
                c1 += 1
            elif board[row][col + i] == board[row][col + i + 1] == board[row][col + i + 2] == 3 - player and board[row][col + i - 1] == 0:
                c2 += 1
    # diagonal
    for col in range(4):
        for row in range(5, 2, -1):
            if board[row][col] == board[row - 1][col + 1] == board[row - 2][col + 2] == player and board[row - 3][col + 3] == 0:
                c1 += 1
            elif board[row][col] == board[row - 1][col + 1] == board[row - 2][col + 2] == 3 - player and board[row - 3][col + 3] == 0:
                c2 += 1
        for row in range(3):
            if board[row][col] == board[row + 1][col + 1] == board[row + 2][col + 2] == player and board[row + 3][col + 3] == 0:
                c1 += 1
            elif board[row][col] == board[row + 1][col + 1] == board[row + 2][col + 2] == 3 - player and board[row + 3][col + 3] == 0:
                c2 += 1
    return c1 , c2

def count_open_couples_on_both_sides(board, player):
    c = 0

    # horizontal
    for row in range(6):
        for col in range(4):
            if board[row][col] == board[row][col + 3] == 0 and board[row][col + 1] == board[row][col + 2] == player:
                c += 1
            elif board[row][col] == board[row][col + 3] == 0 and board[row][col + 1] == board[row][col + 2] == 3 - player:
                c -= 1
    # diagonal
    for col in range(4):
        for row in range(5, 2, -1):
            if board[row][col] == board[row - 3][col + 3] == 0 and board[row - 1][col + 1] == board[row - 2][col + 2] == player:
                c += 1
            elif board[row][col] == board[row - 3][col + 3] == 0 and board[row - 1][col + 1] == board[row - 2][col + 2] == 3 - player:
                c -= 1
        for row in range(3):
            if board[row][col] == board[row + 3][col + 3] == 0 and board[row + 1][col + 1] == board[row + 2][col + 2] == player:
                c += 1
            elif board[row][col] == board[row + 3][col + 3] == 0 and board[row + 1][col + 1] == board[row + 2][col + 2] == 3 - player:
                c -= 1
    return c

def count_forks(board, player, my, op):
    c = my / 2 - op / 2
    return c




