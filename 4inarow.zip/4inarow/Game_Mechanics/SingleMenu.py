from Game_Mechanics import SinglePlayer


def run_single_menu(screen, colors, FRAME_RATE, clock, player1, player2):
    # Initiate fonts
    SinglePlayer.run_single_player_game(screen, colors, FRAME_RATE, clock, player1, player2)