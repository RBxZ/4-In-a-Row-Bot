for row in list(range(6))[::-1]:
    print(row)